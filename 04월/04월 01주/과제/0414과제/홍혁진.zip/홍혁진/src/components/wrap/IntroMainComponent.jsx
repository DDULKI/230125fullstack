import React from 'react';

const IntroMainComponent = () => {
    return (
        <main id='main' className='sub-page intro'>
            <h1>인트로</h1>
        </main>
    );
};

export default IntroMainComponent;