package kurly;

public class Gaib {
    public static void main(String[] args) {
        
    }
}
